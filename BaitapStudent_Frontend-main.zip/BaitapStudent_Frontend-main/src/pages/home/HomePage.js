import React from 'react'
import Header from '../../components/header/Header'

export default function HomePage() {
  return (
    <div>
        <Header />
      Home page
    </div>
  )
}
